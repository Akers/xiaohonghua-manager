package com.akers.xiaohonghua.project.family.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.akers.xiaohonghua.framework.aspectj.lang.annotation.Log;
import com.akers.xiaohonghua.framework.aspectj.lang.enums.BusinessType;
import com.akers.xiaohonghua.project.family.domain.XhhFamilyUser;
import com.akers.xiaohonghua.project.family.service.IXhhFamilyUserService;
import com.akers.xiaohonghua.framework.web.controller.BaseController;
import com.akers.xiaohonghua.framework.web.domain.AjaxResult;
import com.akers.xiaohonghua.common.utils.poi.ExcelUtil;
import com.akers.xiaohonghua.framework.web.page.TableDataInfo;

/**
 * 用户家庭关联Controller
 * 
 * @author ruoyi
 * @date 2023-07-24
 */
@RestController
@RequestMapping("/family/admin/familyuser")
public class XhhFamilyAdminFamilyUserController extends BaseController
{
    @Autowired
    private IXhhFamilyUserService xhhFamilyUserService;

    /**
     * 查询用户家庭关联列表
     */
    @PreAuthorize("@ss.hasPermi('family:admin:familyuser:list')")
    @GetMapping("/list")
    public TableDataInfo list(XhhFamilyUser xhhFamilyUser)
    {
        IPage<XhhFamilyUser> page = xhhFamilyUserService.selectXhhFamilyUserList(getPage(), xhhFamilyUser);
        return getDataTable(page);
    }

    /**
     * 导出用户家庭关联列表
     */
    @PreAuthorize("@ss.hasPermi('family:admin:familyuser:export')")
    @Log(title = "用户家庭关联", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, XhhFamilyUser xhhFamilyUser)
    {
        List<XhhFamilyUser> list = xhhFamilyUserService.selectXhhFamilyUserList(xhhFamilyUser);
        ExcelUtil<XhhFamilyUser> util = new ExcelUtil<XhhFamilyUser>(XhhFamilyUser.class);
        util.exportExcel(response, list, "用户家庭关联数据");
    }

    /**
     * 获取用户家庭关联详细信息
     */
    @PreAuthorize("@ss.hasPermi('family:admin:familyuser:query')")
    @GetMapping(value = "/{familyUserId}")
    public AjaxResult getInfo(@PathVariable("familyUserId") Long familyUserId)
    {
        return success(xhhFamilyUserService.selectXhhFamilyUserByFamilyUserId(familyUserId));
    }

    /**
     * 新增用户家庭关联
     */
    @PreAuthorize("@ss.hasPermi('family:admin:familyuser:add')")
    @Log(title = "用户家庭关联", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody XhhFamilyUser xhhFamilyUser)
    {
        return toAjax(xhhFamilyUserService.insertXhhFamilyUser(xhhFamilyUser));
    }

    /**
     * 修改用户家庭关联
     */
    @PreAuthorize("@ss.hasPermi('family:admin:familyuser:edit')")
    @Log(title = "用户家庭关联", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody XhhFamilyUser xhhFamilyUser)
    {
        return toAjax(xhhFamilyUserService.updateXhhFamilyUser(xhhFamilyUser));
    }

    /**
     * 删除用户家庭关联
     */
    @PreAuthorize("@ss.hasPermi('family:admin:familyuser:remove')")
    @Log(title = "用户家庭关联", businessType = BusinessType.DELETE)
	@DeleteMapping("/{familyUserIds}")
    public AjaxResult remove(@PathVariable Long[] familyUserIds)
    {
        return toAjax(xhhFamilyUserService.deleteXhhFamilyUserByFamilyUserIds(familyUserIds));
    }
}
